const { ServiceBusClient } = require("@azure/service-bus");

module.exports = async function (context, eventGridEvent) {
    context.log('Evento recibido:', eventGridEvent);

    const connectionString = "Endpoint=sb://eda-lab-webinar.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=UZxWeXyGqtsKh3Sxw4LtpfQgsDsO1CBJb+ASbLy0cyA=";
    const queueName = "OrderProcessingQueue";

    const sbClient = new ServiceBusClient(connectionString);
    const sender = sbClient.createSender(queueName);

    const message = {
        body: eventGridEvent.data,
        contentType: "application/json",
        label: "NewOrder",
        messageId: eventGridEvent.id
    };

    try {
        await sender.sendMessages(message);
        context.log('Mensaje enviado a Service Bus:', message);
    } catch (error) {
        context.log('Error enviando mensaje a Service Bus:', error);
    } finally {
        await sender.close();
        await sbClient.close();
    }
};