const { MongoClient } = require('mongodb');

module.exports = async function (context, mySbMsg) {
    context.log('Mensaje recibido de Service Bus:', mySbMsg);

    const mongoUri = "mongodb://webinar-eda-cosmosdb:pAS0svyrSwjn3c2Litim1PZN8lNJqmMStCTbSFqY9EuCIkDYXmTXr3vF0C18bBR2uPYyTFgcwUcPACDbD9IZsQ==@webinar-eda-cosmosdb.mongo.cosmos.azure.com:10255/?ssl=true&retrywrites=false&maxIdleTimeMS=120000&appName=@webinar-eda-cosmosdb@";
    const client = new MongoClient(mongoUri, { useNewUrlParser: true, useUnifiedTopology: true });

    try {
        await client.connect();
        const database = client.db("EDA-Lab-DB");
        const orders = database.collection("Orders");
       
        
        // Almacenar directamente el objeto en Cosmos DB
        const order = mySbMsg;  // Ya es un objeto

        // Asegúrate de que el objeto sea serializable a JSON
        try {
            JSON.stringify(order);  // Si esto falla, entonces el objeto no es válido
        } catch (error) {
            context.log('Error: El objeto recibido no es válido para JSON:', error);
            return;
        }

        const result = await orders.insertOne(order);
        
        context.log(`Pedido almacenado con el id: ${result.insertedId}`);
    } catch (error) {
        context.log('Error almacenando el pedido en Cosmos DB:', error);
    } finally {
        await client.close();
    }
};
